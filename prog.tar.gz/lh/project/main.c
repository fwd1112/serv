#include "main.h"
#include <stdlib.h>
#include <arpa/inet.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>

#include <sys/ioctl.h>
#include <net/if.h>


struct file_data{
 	int path_length;
 	char *filepath;
 	int type_length;
 	char *file_type;
 	int data_length;
 	char *file_data;
 	int action_length;
 	char *action;
 	int uurl_length;
 	char *url;
 };
char buf[1024];
int main()
{
	struct file_data *f=malloc(sizeof(struct file_data)*10);
	char addr [200]="192.168.10.7";

	int ret1=scan_and_populate_files(f);

	struct sockaddr_in server;
	int sock=socket(AF_INET,SOCK_STREAM,0);
	if(sock==-1)
	{
		printf("socket error %d\n",errno);
		exit(0);
	}
    struct ifreq ifr;
    ifr.ifr_addr.sa_family = AF_INET;
    memcpy(ifr.ifr_name, "eno1", IFNAMSIZ - 1);
    ioctl(sock, SIOCGIFADDR, &ifr);
    char ip_address[15];
    strcpy(ip_address, inet_ntoa(((struct sockaddr_in*)&ifr.ifr_addr)->sin_addr));
    printf("bound to %s\n",ip_address);


	server.sin_family = AF_INET;
	server.sin_addr.s_addr = inet_addr(ip_address);

    server.sin_port = htons(5002);
	int ret=bind(sock,(struct sockaddr *)&server,sizeof(server));
	if(ret!=0)
	{printf("bind error\n");exit(0);}
	if(listen(sock,3)!=0)
	{
		printf("listen error %d\n",errno);
		exit(0);
	}
	memset(buf,0,1024);
	struct sockaddr_in client;
	while(1)
	{
		socklen_t len=sizeof(client);
		int con=accept(sock,(struct sockaddr *)&client,&len);
		//if(con<0)
		//{printf("accept error %d\n",errno);exit(0);}
		//printf("%d>>\n",con);
		int x=0;


		while(x<1024)
		{
			int o=0;
			int valread=read(con,&buf[x],1024);
			x=x+valread;
			int f1=0;
			if(x>100)
			{

				buf[x]='\0';
				printf("%s\n",buf);
				//printf("%s\n",buf);
				char *token=strtok(buf,"\n");
				while(token!=NULL)
				{
					if(strncmp(token+strlen(token)-strlen("HTTP/1.1")-1,"HTTP/1.1",strlen("HTTP/1.1"))==0)
					{
						char *temp=token+4;

						char *request=malloc(500);//
						int j=0;

						while(j<(strlen(token)-4))
						{
							if(temp[j]==' ')
							{
								request[j]='\0';
							}
							request[j]=temp[j];
							j++;
							break;
						}

						j=0;

						//if(strncmp(token,"GET",3)==0)
						//while(strncmp(request,(f+j)->url,strlen(request))==0)
						{
							//printf("FOUND MATCHING FILE %.*s %s\n%s\n",10,request,(f+j)->url,buf);
							//printf("%s\n",(f+j)->filepath);

							//if(strncmp(temp,"/",1)==0)
							{
								f1=1;
								//printf("dir GET request received\n");

								int k=0;
								while(1)
								{
									if(temp[k]==' ')
									break;
									k++;
								}
								temp[k]='\0';
								k=0;
								int i=0;
								while(i<ret1)
								{

									printf("looping and matching url against f+%d\n",i);
									if(strncmp((f+i)->url,temp,strlen(temp))==0)
									if(strncmp((f+i)->action,"file",4)==0)
									{
										printf("looping found one match %s\n",(f+i)->url);

										//if(strncmp(f[i].action,"file",4)==0)
										{
											printf("checking file\n");
											//printf("file found\n");
											char b[124];


											memcpy(b,HTTP_RESPONSE_OK,strlen(HTTP_RESPONSE_OK));
											int r=write(con,b,strlen(HTTP_RESPONSE_OK));
											if(r==strlen(HTTP_RESPONSE_OK))
											printf("OK sent\n");
											memset(b,0,strlen(HTTP_RESPONSE_OK));

											int content_length=strlen(HTTP_RESPONSE_OK)+strlen(HTTP_RESPONSE_CONTENT_TYPE);

											//r=write(con,b,strlen(HTTP_RESPONSE_CONTENT_TYPE));
											char str[10];
											//printf("???????%s  %d\n",(f+i)->file_data,f[i].data_length);
											sprintf(str, "%d\r\n", f[i].data_length);
											int strl=strlen(str);

											memcpy(b,HTTP_RESPONSE_CONTENT_LENGTH,strlen(HTTP_RESPONSE_CONTENT_LENGTH));

											memcpy(b+strlen(HTTP_RESPONSE_CONTENT_LENGTH),str,strlen(HTTP_RESPONSE_CONTENT_LENGTH)+strlen(str));

											if(strcmp((f+j)->file_type,"css")==0)
											{
												//sleep(2);
												//printf("%s\n",(f+j)->file_data);
												memset(b,0,strlen(HTTP_RESPONSE_CONTENT_TYPE_CSS));
												memcpy(b,HTTP_RESPONSE_CONTENT_TYPE_CSS,strlen(HTTP_RESPONSE_CONTENT_TYPE_CSS));
												r=write(con,b,strlen(HTTP_RESPONSE_CONTENT_TYPE_CSS));
												//sleep(2);
												if(r==strlen(HTTP_RESPONSE_CONTENT_TYPE_CSS))
													printf("response type css sent\n");


											}
											else if(strcmp((f+j)->file_type,"js")==0)
											{
												//sleep(2);
												memset(b,0,124);
												memcpy(b,HTTP_RESPONSE_CONTENT_TYPE_JS,strlen(HTTP_RESPONSE_CONTENT_TYPE_JS));
												r=write(con,b,strlen(HTTP_RESPONSE_CONTENT_TYPE_JS));

												if(r==strlen(HTTP_RESPONSE_CONTENT_TYPE_JS))
												{
													printf("response type js sent\n");
												}


											}
											else{
												memcpy(b,HTTP_RESPONSE_CONTENT_TYPE,strlen(HTTP_RESPONSE_CONTENT_TYPE));
												r=write(con,b,strlen(HTTP_RESPONSE_CONTENT_TYPE));

												memset(b,0,strlen(HTTP_RESPONSE_CONTENT_TYPE));

												//memcpy(b,HTTP_RESPONSE_CONTENT_TYPE,strlen(HTTP_RESPONSE_CONTENT_TYPE));
												//r=write(con,b,strlen(HTTP_RESPONSE_CONTENT_TYPE));

											}
											r=write(con,(f+i)->file_data,(f+i)->data_length);										//r=write(con,b,strlen(HTTP_RESPONSE_CONTENT_LENGTH)+strlen(str));
											//r=write(con,(f+i)->file_data,(f+i)->data_length);

											if(r==(f+j)->data_length)
												printf("ALL SENT\n");

											//close(con);
											sleep(3);
											close(con);
											close(con);
											o=1;
											break;

										}


										//printf("<<%d>> %d\n",r,errno);
									}
									else
									{
										//printf("%s\n",f[i].filepath);
									}
									i++;
								if(i==(ret1-1))
								{
									if(o=0)
									{
										o=1;
										close(con);
										break;

									}

								}
								}
							}
							if(o==1)
								break;
							j++;
					}
						

					}	
					if(o==1)
						break;
					token=strtok(NULL,"\n");
					
				}
				if(o==1)
				break;
				break;
			}
			if(o==1)
				break;

			//printf("%s\n",buf);
		}
		//printf("%s\n",buf);
		
		
	}
	
	
	
//close(sock);
	//printf("%d is a %s\n\n",x,f[0].file_type);
	return 0;
}
