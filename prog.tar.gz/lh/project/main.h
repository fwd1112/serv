
#include <sys/socket.h>

#include <pthread.h>
#include <stdio.h>

#define HTTP_RESPONSE_OK "HTTP/1.1 200 OK\r\n"
#define HTTP_RESPONSE_CONTENT_TYPE "Content-Type: text/html\r\n\r\n"
#define HTTP_RESPONSE_CONTENT_TYPE_CSS "Content-Type: text/css\r\n\r\n"
#define HTTP_RESPONSE_CONTENT_TYPE_JS "Content-Type: text/js\r\n\r\n"
#define HTTP_RESPONSE_CONTENT_LENGTH "Content-Length:"
#define HTTP_RESPONSE_CONNECTION_CLOSED "Connection: Closed"


int scan_and_populate_files();

