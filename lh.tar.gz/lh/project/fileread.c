#include "fileread.h"
#include <errno.h>
#include <string.h>

char **files;
int cnt_files=0;
char *buffer;

int fd_length;

 struct file_data{
 	int path_length;
 	char *filepath;
 	int type_length;
 	char *file_type;
 	int data_length;
 	char *file_data;
 	int action_length;
 	char *action;
 	int uurl_length;
 	char *url;
 };


struct file_data *fd2;

int find_files_count(int fd,int ret)
{
	int x=0;
	int count=0;
	
	while(x<ret)
	{
		if(buffer[x]=='\n')
		{
			count++;
		}	
		x++;
	}
	

	return count;
	
}
//*
int split(char *arr,char ***out)
{
	int x=0;
	int i=0;
	int t=0;
	
	int len=strlen(arr);

	while(x<len)
	{
		if(*(arr+x)==',')
		i++;
		x++;
	}
	x=0;

	*out=malloc(sizeof(char *)*6);
	*(*out+0)=malloc(100);
	*(*out+1)=malloc(100);
	for(int j=0;j<(5);j++)
	{
		*(*out+j)=malloc(sizeof(char)*150);
		if(*(*out+j)==NULL)
		{printf("NULL\n");exit(0);}
	}
	//memcpy(*(*out+0),"hello",6);

//	memcpy(*(*out+1),"hello",6);

//	memcpy(*(*out+2),"hello",6);
	
	i=0;
	while(x<len)
	{
		if(arr[x]==',')
		{
			*(*(*out+i)+t)='\0';
			i++;
			t=0;
			x++;
			
		}
		
		
		*(*(*out+i)+t)=arr[x];
		t++;
		x++;
	}
	
	
	
	return ++i;
}

char *reverse(char *str,char *sp)
{
	int x=strlen(str)-1;
	int i1=strlen(str);
	int i=0;
	if(str[x]=='\0');;
	//printf("error\n");
	
	while(i<i1)
	{
		if(str[x]!=0)
		sp[i]=str[x];
		//printf("!%c\n",str[x]);
			
		
		i++;
		x--;
	}
	sp[i]='\0';
	return sp;
	
	

}
 

 int loadfile(struct file_data *f)
 {
	 int fd=open(f->filepath,0);
	 struct stat st;
	 int sfd=stat(f->filepath,&st);
	// printf("%s's file length is %zu\n",f->filepath,st.st_size);
	 f->data_length=st.st_size+2;
	 f->file_data=malloc(sizeof(char)*st.st_size+2);
	 int bytes_read=read(fd,f->file_data,f->data_length);
	 if((bytes_read+2)<((int)f->data_length))
	 {
		 printf("mismatch reading filedata %d %d\n",bytes_read,(int)f->data_length);


	 }
	 else
	 {
		 f->file_data[f->data_length-1]='\0';
		// printf("%s\n",f.file_data);
	 }

	 return 0;

 }




int scan_and_populate_files(struct file_data *fdata)
{
	int fd=open("./files.txt",0);
	fd2=malloc(sizeof(struct file_data )*7);

	if(fd==-1)
	{
		printf("open in scan_and_populate_files %d\n",errno);
		exit(0);
	}	
	struct stat st;
	int sfd=stat("./files.txt",&st);
	if(sfd==-1)
	{
		printf("stat in fileread.c -- scan_and poputate_files(...) %d\n",errno);
		exit(0);
	}
	int bytes_to_read=st.st_size;	
	//printf("bytes read %d\n",bytes_read);
	buffer=malloc(sizeof(char)*bytes_to_read);
	int bytes_read=read(fd,buffer,bytes_to_read);
	
	//printf("bytes read=%d sfd=%d fd=%d\n ",bytes_read,bytes_to_read,fd);
	if(bytes_to_read==bytes_read)
	buffer[bytes_read]='\0';
	int count_files=find_files_count(fd,bytes_read);
	printf("%d\n",count_files-1);
	
	char *token=strtok(buffer,"\n");
	int i=0;


	int x=0;
	
	while(token!=NULL)
	{

		char **arr;
	//	printf("<_____________________________________\n");
		int ret=split(token,&arr);
		//printf("_____________________________________>\n");
		for(int x=0;x<ret;x++);
		//printf("<%s> ,..%d %zu\n",arr[x],ret,strlen(arr[x]));
		
		//printf("-%s\n",token);
//		for(x=0;x<ret;x++);

		if(i<10)
		{

	

			(fd2+i)->uurl_length=strlen(arr[0])+1;
			(fd2+i)->url=malloc(strlen(arr[0])+1);

			memcpy((fd2+i)->url,arr[0],strlen(arr[0]));
			(fd2+i)->path_length=strlen(arr[2]);



//			arr[2][(fd2+i)->path_length]='\0';



			(fd2+i)->filepath=malloc(sizeof(char)*1024);
			//memset((fd2+i)->filepath,0,1024);
			//printf("")



			memcpy((fd2+i)->filepath,arr[2],strlen(arr[2]));
			(fd2+i)->filepath[strlen(arr[2])]=0;

			memset(arr[2],0,strlen(arr[2]));
			//(fd2+i)->filepath[strlen(arr[2])+1]='\0';






			//(fd2+i)->filepath[strlen(arr[2])]='\0';
			//printf("[%s]\n",(fd2+i)->filepath);


			//printf("''%s\n",(fd2+i)->filepath+(strlen((fd2+i)->filepath)+-4));
			if(strncmp((fd2+i)->filepath+(strlen((fd2+i)->filepath)-3),".js",3)==0)
			{
				
				(fd2+i)->type_length=strlen("js")+1;
				(fd2+i)->file_type=malloc(strlen("js")+1);
				memcpy((fd2+i)->file_type,"js",3);

			}

			if(strncmp((fd2+i)->filepath+(strlen((fd2+i)->filepath)-4),".css",4)==0)
			{
				//printf("css found\n");
				(fd2+i)->type_length=strlen("css")+1;
				(fd2+i)->file_type=malloc(strlen("css")+1);
				memcpy((fd2+i)->file_type,"css",4);
			}
			
			if(strncmp((fd2+i)->filepath+(strlen((fd2+i)->filepath)-5),".html",5)==0)
			{
				//printf("css found\n");
				(fd2+i)->type_length=strlen("html")+1;
				(fd2+i)->file_type=malloc(strlen("html")+1);
				memcpy((fd2+i)->file_type,"html",4);
			}

			(fd2+i)->action_length=strlen(arr[1])+1;
			(fd2+i)->action=malloc(sizeof(char)*(fd2+i)->action_length);
			memcpy((fd2+i)->action,arr[1],strlen(arr[1])+1);
			
			//if(strncmp((fd2+i)->filepath+(strlen((fd2+i)->filepath)-3),".js",2)==0)

			if(strcmp((fd2+i)->action,"file")==0)
			{
				struct stat st1;

				int r=open((fd2+i)->filepath,0);

				int r2=stat((fd2+i)->filepath,&st1);

				if(r2!=0)
				{printf("error stat %d %d %d\n",errno,r2,r);exit(0);}
				//printf("%zu\n",st1.st_size);
				(fd2+i)->data_length=st1.st_size;
				(fd2+i)->file_data=malloc((fd2+i)->data_length);
				int ret=read(r,(fd2+i)->file_data,(fd2+i)->data_length);
				if((fd2+i)->data_length==ret)
				{
					(fd2+i)->file_data[(fd2+i)->data_length]='\0';
					//printf("%s\n%d\n",(fd2+i)->file_data,i);
				}
				close(r);
				
			}

			//			memcpy()
//			printf("%s !%d\n",(fd2+i)->url,(fd2+i)->uurl_length);
		}	
				
		token=strtok(NULL,"\n");
		
		//printf("%d\n",ret);
		i++;
		//printf("~%d\n",i);
		for(int x=0;x<ret;x++)
		free(arr[x]);


		
	}

	memcpy(fdata,fd2,sizeof(struct file_data)*i);
	
	return i;
	
	//cnt_files=count_files;
	//int count_pages=find_pages_count(fd,bytes_read,count_files);
	//printf("%s'''''''''''''''''''''''\n",(fd2+cnt_files)->file_data);
	//printf("%d\n",count);
	
	return 0;
	


}
